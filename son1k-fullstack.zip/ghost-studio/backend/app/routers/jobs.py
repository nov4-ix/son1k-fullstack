# Jobs router integrado con Celery
