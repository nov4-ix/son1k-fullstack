# Funciones de DB para jobs
